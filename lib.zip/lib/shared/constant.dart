import 'package:flutter/material.dart';

class Constants {
  static String apiKey = "AIzaSyDlTJfnRTx-8zyUcX3W94i38gEK17_O7zY";
  static String appId = "1:454245263006:web:383b1217a1df48e58dfd8f";
  static String messagingSenderId = "454245263006";
  static String projectId = "chatapp-42f97";
  final primaryColour2 = Colors.yellow[700];
  //Color(0xFFee7b64)
}
